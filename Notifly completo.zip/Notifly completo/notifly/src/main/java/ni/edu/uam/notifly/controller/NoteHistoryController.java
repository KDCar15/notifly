package ni.edu.uam.notifly.controller;

import java.net.URL;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.ResourceBundle;

import javafx.beans.property.ReadOnlyObjectWrapper;
import javafx.beans.property.ReadOnlyStringWrapper;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.stage.Stage;
import ni.edu.uam.notifly.App;
import ni.edu.uam.notifly.dao.Dao;
import ni.edu.uam.notifly.entity.Areas;
import ni.edu.uam.notifly.entity.Clasificaciones;
import ni.edu.uam.notifly.entity.EstadosNota;
import ni.edu.uam.notifly.entity.Notas;
import ni.edu.uam.notifly.entity.TiposNota;

public class NoteHistoryController implements Initializable {

    private final Dao dao = new Dao();
    private static final DateTimeFormatter FORMATO =
            DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");

    @FXML private ComboBox<String> cb_tipo;
    @FXML private ComboBox<String> cb_estado;
    @FXML private ComboBox<String> cb_area;
    @FXML private ComboBox<String> cb_categoria;
    @FXML private ComboBox<String> cb_facultad;
    @FXML private DatePicker dp_fecha_inicio;
    @FXML private DatePicker dp_fecha_fin;

    @FXML private TableView<HistorialFila> tv_resultados;
    @FXML private TableColumn<HistorialFila, String> tc_acceso;
    @FXML private TableColumn<HistorialFila, Integer> tc_id;
    @FXML private TableColumn<HistorialFila, String> tc_tipo;
    @FXML private TableColumn<HistorialFila, String> tc_facultad;
    @FXML private TableColumn<HistorialFila, String> tc_categoria;
    @FXML private TableColumn<HistorialFila, String> tc_area;
    @FXML private TableColumn<HistorialFila, String> tc_estado;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        configurarTabla();
        cargarFiltros();
        cargarHistorial();
    }

    private void configurarTabla() {
        tc_acceso.setCellValueFactory(d -> new ReadOnlyStringWrapper(d.getValue().getAcceso()));
        tc_id.setCellValueFactory(d -> new ReadOnlyObjectWrapper<>(d.getValue().getId()));
        tc_tipo.setCellValueFactory(d -> new ReadOnlyStringWrapper(d.getValue().getTipo()));
        tc_facultad.setCellValueFactory(d -> new ReadOnlyStringWrapper(d.getValue().getFacultad()));
        tc_categoria.setCellValueFactory(d -> new ReadOnlyStringWrapper(d.getValue().getCategoria()));
        tc_area.setCellValueFactory(d -> new ReadOnlyStringWrapper(d.getValue().getArea()));
        tc_estado.setCellValueFactory(d -> new ReadOnlyStringWrapper(d.getValue().getEstado()));
    }

    private void cargarFiltros() {
        cb_tipo.getItems().setAll("Todos");
        for (TiposNota t : dao.getAll("TiposNota.findAll", TiposNota.class))
            cb_tipo.getItems().add(t.getNombreTipo());
        cb_tipo.getSelectionModel().selectFirst();

        cb_estado.getItems().setAll("Todos");
        for (EstadosNota e : dao.getAll("EstadosNota.findAll", EstadosNota.class))
            cb_estado.getItems().add(e.getNombreEstado());
        cb_estado.getSelectionModel().selectFirst();

        cb_categoria.getItems().setAll("Todas");
        for (Clasificaciones c : dao.getAll("Clasificaciones.findAll", Clasificaciones.class))
            cb_categoria.getItems().add(c.getNombreClasificacion());
        cb_categoria.getSelectionModel().selectFirst();

        cb_facultad.getItems().setAll("Todas");
        cb_area.getItems().setAll("Todas");
        for (Areas a : dao.getAll("Areas.findAll", Areas.class)) {
            if (Boolean.TRUE.equals(a.getEsFacultad()))
                cb_facultad.getItems().add(a.getNombreArea());
            else
                cb_area.getItems().add(a.getNombreArea());
        }
        cb_facultad.getSelectionModel().selectFirst();
        cb_area.getSelectionModel().selectFirst();
    }

    private void cargarHistorial() {
        List<Object[]> filas = dao.buscarHistorial(
                valor(cb_tipo), valor(cb_estado), valor(cb_categoria),
                valor(cb_facultad), valor(cb_area),
                dp_fecha_inicio.getValue(), dp_fecha_fin.getValue());

        tv_resultados.getItems().clear();
        for (Object[] f : filas) {
            String acceso = f[0] == null ? "" :
                    ((java.util.Date) f[0]).toInstant()
                            .atZone(java.time.ZoneId.systemDefault())
                            .toLocalDateTime().format(FORMATO);
            tv_resultados.getItems().add(new HistorialFila(
                    acceso,
                    ((Number) f[1]).intValue(),
                    texto(f[2]), texto(f[3]), texto(f[4]),
                    texto(f[5]), texto(f[6])));
        }
    }

    private String valor(ComboBox<String> combo) {
        return combo.getValue();
    }

    private String texto(Object valor) {
        return valor == null ? "" : valor.toString();
    }

    @FXML
    public void buscar(ActionEvent event) {
        LocalDate desde = dp_fecha_inicio.getValue();
        LocalDate hasta = dp_fecha_fin.getValue();
        if (desde != null && hasta != null && desde.isAfter(hasta)) {
            alerta(Alert.AlertType.WARNING, "Fechas incorrectas",
                    "La fecha inicial no puede ser posterior a la fecha final.");
            return;
        }
        cargarHistorial();
    }

    @FXML
    public void limpiar(ActionEvent event) {
        cb_tipo.getSelectionModel().selectFirst();
        cb_estado.getSelectionModel().selectFirst();
        cb_categoria.getSelectionModel().selectFirst();
        cb_facultad.getSelectionModel().selectFirst();
        cb_area.getSelectionModel().selectFirst();
        dp_fecha_inicio.setValue(null);
        dp_fecha_fin.setValue(null);
        cargarHistorial();
    }

    @FXML
    public void visualizar(ActionEvent event) {
        HistorialFila seleccion = tv_resultados.getSelectionModel().getSelectedItem();
        if (seleccion == null) {
            alerta(Alert.AlertType.WARNING, "Registro no seleccionado",
                    "Selecciona un registro del historial para visualizar la nota.");
            return;
        }

        Notas nota = dao.obtenerNotaConDetalles(seleccion.getId());
        if (nota == null) {
            alerta(Alert.AlertType.ERROR, "Nota no encontrada",
                    "No fue posible recuperar la nota seleccionada.");
            return;
        }

        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource(
                    "/ni/edu/uam/notifly/notedetails.fxml"));
            Parent root = loader.load();
            NoteDetailsController controller = loader.getController();
            controller.setNota(nota);

            Stage stage = new Stage();
            stage.setTitle("Detalles de la nota #" + nota.getIdNota());
            stage.setScene(new Scene(root));
            stage.setOnHidden(e -> {
                controller.cerrarVentanasHijas();
                cargarHistorial();
            });
            stage.show();
        } catch (Exception e) {
            e.printStackTrace();
            alerta(Alert.AlertType.ERROR, "Error",
                    "No fue posible abrir los detalles de la nota.");
        }
    }

    @FXML
    public void volver() {
        try {
            App.setRoot("mainscreen");
        } catch (java.io.IOException e) {
            alerta(Alert.AlertType.ERROR, "Error",
                    "No se pudo volver al menú principal.");
        }
    }

    private void alerta(Alert.AlertType tipo, String titulo, String mensaje) {
        Alert a = new Alert(tipo);
        a.setTitle(titulo);
        a.setHeaderText(null);
        a.setContentText(mensaje);
        a.showAndWait();
    }

    public static class HistorialFila {
        private final String acceso, tipo, facultad, categoria, area, estado;
        private final Integer id;

        public HistorialFila(String acceso, Integer id, String tipo,
                String facultad, String categoria, String area, String estado) {
            this.acceso = acceso;
            this.id = id;
            this.tipo = tipo;
            this.facultad = facultad;
            this.categoria = categoria;
            this.area = area;
            this.estado = estado;
        }
        public String getAcceso() { return acceso; }
        public Integer getId() { return id; }
        public String getTipo() { return tipo; }
        public String getFacultad() { return facultad; }
        public String getCategoria() { return categoria; }
        public String getArea() { return area; }
        public String getEstado() { return estado; }
    }
}
